import React from "react";

const Card = () => {
  return (
    <button
      style={{
        backgroundColor: "lime",
        height: 400,
        width: 300,
      }}
    >
      1v1
    </button>
  );
};

export default Card;
