
import React from "react";

export default function Logo(props) {
  return (
    <div {...props}>
      <p>Logo</p>
    </div>
  );
}