import React, { useRef, useState, Suspense } from "react";
export const Colors = {
	WHITE: 0,
	BLACK: 1,
};
